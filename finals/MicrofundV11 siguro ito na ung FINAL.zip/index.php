<?php 

session_start();



	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$emailaddress = $_POST['emailaddress'];
		$password = $_POST['password'];

		if(!empty($emailaddress) && !empty($password) && !is_numeric($emailaddress))
		{

			//read from database
			$query = "select * from user where emailaddress = '$emailaddress' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['password'] === $password)
					{

						
				
					if($user_data['access_level'] == "1")
					{

						$_SESSION['idnumber'] = $user_data['idnumber'];
						header("Location: /bookkeeperv2");
						die;
					}

					if($user_data['access_level'] == "2")
					{

						$_SESSION['idnumber'] = $user_data['idnumber'];
						header("Location: /userv2");
						die;
					}
				}








				}
			}
			
			echo '<script>alert("Invalid username or password!")</script>';
		}else
		{
			echo '<script>alert("Invalid username or password!")</script>';
		}
	}

?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="./css/style.css"> 
</head>
<body>

<!--start heading description-->	
<h1>Student Assistance <br> Micro Fund</h1>
<h4> Student Assistance Micro Fund is a Recording System <br>
of the transaction of tuition fee fund for lending. <br>
Students will borrow money to spend on their tuition<br>
while returning the rented money with service.</h4>
<!--end of heading description-->	

<!--start login form-->	
<form method="post">
	  <div class="container">
    <input type="text" placeholder="Enter Email" name="emailaddress" required>
    <input type="password" placeholder="Enter Password" name="password" required>
    <button type="submit">Sign in</button>


  </div>
  <?php
                    if(isset($_SESSION["error"])){
                        $error = $_SESSION["error"];
                        echo "<span>$error</span>";
                    }
                ?>  


</form>
<!--end login form-->	

</body>
</html>