<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>
<!DOCTYPE html>
<html>
<head>
  <html lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="preload" href=".////css/cash.css" as="style">
  <link rel="stylesheet" href=".////css/cash.css" onload="this.media='all'">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<style>
  #content{
    width: 50%;
    margin: 20px auto;
    border: 1px solid #cbcbcb;
}
form{
    width: 50%;
    margin: 20px auto;
}
form div{
    margin-top: 5px;
}
#img_div{
    width: 80%;
    padding: 5px;
    margin: 15px auto;
    border: 1px solid #cbcbcb;
}
#img_div:after{
    content: "";
    display: block;
    clear: both;
}
img{
    float: left;
    margin: 5px;
    width: 300px;
    height: 140px;
}
  </style>
<body>
  <header>
    <a href="index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
    <nav>
      <ul class="nav__links"> 
        <li><a href="index.php">HOME</a></li>
        <li><a class="active-header" href="activity.php">ACTIVITY</a></li>
        <li><a href="borrower-profile.php">PROFILE</a></li>
      </ul>
    </nav>
    <a class="cta" href="logout.php"><button>Logout</button></a>
  </header>


<?php
error_reporting(0);
?>
<?php
  $msg = "";
 
  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
 
    $date = $_POST['date']; 
    $paymentid = $_POST['paymentid']; 
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];   
        $folder = "C:/wamp64/www/bookkeeperv2/image/".$filename;
         
    $db = mysqli_connect("localhost", "root", "", "microfundv2");
 
        // Get all the submitted data from the form
        $sql = "INSERT INTO image (filename, date, paymentid) VALUES ('$filename', '$date', '$paymentid')";
 
        // Execute query
        mysqli_query($db, $sql);

         // Now let's move the uploaded image into the folder: image
        if (move_uploaded_file($tempname, $folder))  {
            $msg = "Image uploaded successfully";
        }else{
            $msg = "Failed to upload image";
      }
        
        echo '<script>alert("Successfull uploaded!")</script>';
        echo '<script>window.location.href = "/userv2/activity.php"</script>';
         
        // Now let's move the uploaded image into the folder: image
        //if (move_uploaded_file($tempname, $folder))  {
            //$msg = "Image uploaded successfully";
        //}else{
            //$msg = "Failed to upload image";
      //}
  }
  
?>
 

  <div id="content">



  <?php

require('readuser.php');

?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
  

  
<?php } ?>



 <?php include 'config.php'; ?>


 
  <form method="POST" action="" enctype="multipart/form-data">


 
    





 
      <select class="form-control" name="paymentid"    required/>
            <?php

              function bor(){
                $conn = DbConnect();
                $id = $_SESSION['idnumber'];
                $paces = $conn->prepare("SELECT * FROM payment_record where idnumber = '$id' ");
                $paces->execute();

                $ans = $paces->setFetchMode(PDO::FETCH_ASSOC);

                while ($pace = $paces->fetch()) {

                  extract($pace);
                  echo "<option value='$paymentid'>Payment ID: $paymentid $pdate Amount: $pamount</option>";

                  # code...
                }
              }
              bor();
            ?>

            
            
          </select><br>





    
    <input type="date" name="date" placeholder="Date" required/><br>
      <input type="file" name="uploadfile" value="" required/>


      
       
      <div>
          <button type="submit" name="upload">UPLOAD</button>
        </div>
  </form>
</div>
</body>
</html>

</body>
</html>