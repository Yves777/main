<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>
<!DOCTYPE html>
<html>
<head>
	<html lang="en">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="preload" href="./css/activity.css" as="style">
	<link rel="stylesheet" href="./css/activity.css" onload="this.media='all'">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
<header>
	<a href="index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
	<nav>
		<ul class="nav__links"> 
			<li><a href="index.php">HOME</a></li>
        <li><a class="active-header" href="activity.php">ACTIVITY</a></li>
        <li><a href="borrower-profile.php">PROFILE</a></li>
		</ul>
	</nav>
	<a class="cta" href="logout.php"><button class="logout-btn">Logout</button></a>
</header>
<?php

require('readuser.php');

?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
<div class="table">
	<div class="borrower">
		<h2><?php echo $results['firstname']; ?> <?php echo $results['middlename']; ?> <?php echo $results['lastname']; ?></h2><?php } ?>
		
	</div>
	<div class="column1">
		<div class="column-left">
			<ul class="activity">
				<li class="header">LEND MONEY</li>
				<li class="grey"><a href="lentpayment.php" class="activity-btn">ADD</a>
				    			</li>
			</ul>
		</div>
		<div class="column-right">
			<ul class="activity">
				<li class="header">WITHDRAW MONEY</li>
				<li class="grey"><a href="withdrawpayment.php" class="activity-btn">ADD</a></li>
				    			
			</ul>
		</div>
	</div>
	<div class="column2">
		<div class="column">
			<ul class="activity1">
				<li class="header1">PROOF OF PAYMENT</li>
				<li class="grey1"><a href="upload.php" class="activity-btn">ADD</a></li>
			</ul>
		</div>
		<div class="column-right1">
			<ul class="activity">
				<li class="header">BORROW MONEY</li>
				<li class="grey"><a href="addborrowrecord.php" class="activity-btn">ADD</a>
				    			</li>
			</ul>
		</div>
	</div>
	<br>
	<br>
	<br>
	<center>
	<div class="column3">
		<div class="middle">
			<ul class="activity">
				<li class="header">PAY MONEY</li>
				<li class="grey"><a href="paymentrecord.php" class="activity-btn">ADD</a>
				    			</li>
			</ul>
		</div>	
	</div></center>
</div>

<script src=".//js/jquery-latest.min.js"></script>
<script>
	$(function() {
		$("#fileupload").change(function(event) {
			var img = URL.createObjectURL(event.target.files[0]);
			$(".upload-img").attr("src", img);
		});
	});
</script>

</body>
</html>
