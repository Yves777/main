<?php 
  require('./database.php');

  if (isset($_POST["create"])) {


    $idnumber = $_POST['idnumber'];
    $lamount = $_POST['lamount'];
    $recievedate = $_POST['recievedate'];
    
    $method = $_POST['method'];
     $status = $_POST['status'];
     $ldescription = $_POST['ldescription'];
    
    
    
    


    $queryCreate = "INSERT INTO lend_record VALUES (null, '$idnumber', '$lamount', '$recievedate', '$method', '$status', '$ldescription')";
    $sqlCreate = mysqli_query($connection, $queryCreate);

    echo '<script>alert("Successfull created!")</script>';
    echo '<script>window.location.href = "/userv2/activity.php"</script>';
    
    
  } else {
    echo '<script>alert("Error!")</script>';
    
  }
?>