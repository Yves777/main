<?php 
  require('./database.php');

 
$id = $_SESSION['idnumber'];

  $queryAccounts = "select * from lend_record where idnumber = '$id'";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
 
?>