
<?php 
  require('./database.php');

 

$id = $_SESSION['idnumber'];
  $queryAccounts = "SELECT 
    ((SELECT coalesce(SUM(lamount),0) FROM lend_record where idnumber = '$id') + 
    (SELECT coalesce(SUM(pamount),0) FROM payment_record where idnumber = '$id')) -
    ((SELECT coalesce(SUM(amount),0) FROM borrow_record where idnumber = '$id') +
    (SELECT coalesce(SUM(wamount),0) FROM withdraw_record where idnumber = '$id')) as currentfunds";





  $sqlAccounts = mysqli_query($connection, $queryAccounts);
 
?>