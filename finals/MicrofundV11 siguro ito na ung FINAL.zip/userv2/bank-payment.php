<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>
<!DOCTYPE html>
<html>
<head> 
  <html lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bank-payment.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
  <header>
    <a href="index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
    <nav>
      <ul class="nav__links"> 
        <li><a class="active-header" href="index.php">HOME</a></li>
        <li><a href="activity.php">ACTIVITY</a></li>
      </ul>
    </nav>
    <a class="cta" href="logout.php"><button>Logout</button></a>
  </header>
  <br>
  <div class="row">
    <div class="col-75">
      <div class="container">
        <form action="/action_page.php">        
          <div class="row">
            <div class="col-50">
              <h2>THROUGH BANK</h2>
              <h3 class="title">Personal Information</h3><br>
              <label for="fname"><i class="fa fa-user"></i> First Name</label>
              <input type="text" id="fname" name="firstname" placeholder="Persneym">

              <label for="lname"><i class="fa fa-user"></i> Last Name</label>
              <input type="text" id="lname" name="lastname" placeholder="Lasneym">

              <label for="adr"><i class="fa fa-university"></i> School</label>
              <input type="text" id="school" name="school" placeholder="School of AMCIS">

              <label for="city"><i class="fa fa-phone"></i> Contact</label>
              <input type="text" id="contact" name="contact" placeholder="0900-000-0000">

              <label for="email"><i class="fa fa-envelope"></i> Email</label>
              <input type="text" id="email" name="email" placeholder="slu@example.com">
            </div>

          <div class="col-50">
              <br><br>
              <h3 class="title">Borrowed Cash and Payment Details</h3><br>
              <div>
              <label for="borrowed-money">Claim Borrowed Money</label>
                <div class="method">
                  <select id="method" name="method">
                    <option value="choose-method">Choose Option</option>
                    <option value="thru-cash">Thru Cash</option>
                    <option value="thru-gcash">Thru GCash</option>
                    <option value="thru-bank">Thru Bank</option>
                  </select>
                </div>
              </div>
              <br>  
              <label for="money-borrowed">Money Borrowed</label>
              <input type="text" id="ccnum" name="cardnumber" placeholder="Specify The Amount">

              <label for="date-borrowed">Date Borrowed</label>
              <input type="text" id="expmonth" name="expmonth" placeholder="MM/DD/YYYY">

              <label for="due-date">Due Date</label>
              <input type="text" id="expmonth" name="expmonth" placeholder="MM/DD/YYYY">

              <div>  
                <label for="payment-method">Method</label>
                  <select id="method2" name="method2">
                    <option value="choose method">Choose Option</option>
                    <option value="weekly">Weekly</option>
                    <option value="biweekly">Biweekly</option>
                    <option value="monthly">Monthly</option>
                </select> 
              </div>

            <br>
            <label for="card-number">Card Number</label>
            <input type="text" id="card-number" name="card-number" placeholder="**** **** **** ****">
            
          </div>
          <input type="submit" value="Apply" class="btn">
        </form>
      </div>
    </div>
  </div>

</body>
</html>
