<?php 
  require('./database.php');

 
$id = $_SESSION['idnumber'];

  $queryAccounts = "select * from borrow_record where idnumber = '$id'";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
 
?>