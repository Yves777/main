<?php 
session_start();


    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);



?>
<!DOCTYPE html>
<html>
<head> 
  <html lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="preload" href="./css/borrower-profile.css" as="style">
  <link rel="stylesheet" href="./css/borrower-profile.css" onload="this.media='all'">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
  <header>
    <a href="index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
    <nav>
      <ul class="nav__links"> 
        <li><a href="index.php">HOME</a></li>
        <li><a href="activity.php">ACTIVITY</a></li>
        <li><a class="active-header" href="borrower-profile.php">PROFILE</a></li>
      </ul>
    </nav>
    <a class="cta" href="logout.php"><button>Logout</button></a>
  </header>
  <?php

require('readborrower-profile.php');

?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
  <div class="row">
    <div class="col-75">
      <div class="container">
      	<div class="title">Personal Information</div>
        <form action="#" method="post">        
          <div class="row">
            <div class="col-50">
              

              <label for="faculty"><i class="fa fa-id-card"></i> ID Number</label>
              <input type="number" id="id-number" value="<?php echo $results['idnumber']; ?>"  readonly>

              <label for="firstname"><i class="fa fa-user-circle"></i> First Name</label>
              <input type="text" id="firstname" value="<?php echo $results['firstname']; ?>" readonly>

              <label for="middlename"><i class="fa fa-user-circle"></i> Middle Name</label>
              <input type="text" id="middlename"  value="<?php echo $results['middlename']; ?>" readonly>

              <label for="lastname"><i class="fa fa-user-circle"></i> Last Name</label>
              <input type="text" id="lastname" value="<?php echo $results['lastname']; ?>" readonly>
            </div>

          <div class="col-50">
              <label for="address"><i class="fa fa-address-book"></i> Address</label>
              <input type="text" id="address"  value="<?php echo $results['houseno']; ?> <?php echo $results['street']; ?> <?php echo $results['barangay']; ?> <?php echo $results['city']; ?> <?php echo $results['province']; ?>" readonly>

              <label for="contact"><i class="fa fa-phone-square"></i> Contact</label>
              <input type="number" id="contact"  value="<?php echo $results['contactnumber']; ?>" readonly>
            
          </div>
          <input type="submit" value="Confirm" class="btn">
        </form>
      </div>
    </div>
  </div>
  <?php } ?>

</body>
</html>
