<?php 
  require('./database.php');

  if (isset($_POST["create"])) {


    $borrowid = $_POST['borrowid'];
    $idnumber = $_POST['idnumber'];
    
    $pdate = $_POST['pdate'];
    $pamount = $_POST['pamount'];
    $method = $_POST['method'];
    $pstatus = $_POST['pstatus'];
    $pdescription = $_POST['pdescription'];
    
    


    $queryCreate = "INSERT INTO payment_record VALUES (null,'$borrowid', '$idnumber', '$pdate', '$pamount', '$method', '$pstatus', '$pdescription')";
    $sqlCreate = mysqli_query($connection, $queryCreate);

    echo '<script>alert("Successfull created!")</script>';
    echo '<script>window.location.href = "/userv2/activity.php"</script>';
    
  } else {
    echo '<script>alert("Error!")</script>';
    
  }
?>