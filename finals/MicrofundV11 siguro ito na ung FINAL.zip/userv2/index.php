<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>
<!DOCTYPE html>
<html>
<head>
  <html lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="preload" href=".////css/StylesH.css" as="style">
  <link rel="stylesheet" type="text/css" href=".////css/StylesH.css" onload="this.media='all'">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<header>
  <a href="index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
  <nav>
    <ul class="nav__links"> 
      <li><a class="active-header" href="index.php">HOME</a></li>
        <li><a href="activity.php">ACTIVITY</a></li>
        <li><a href="borrower-profile.php">PROFILE</a></li>
    </ul>
  </nav>
  <a class="cta" href="logout.php"><button class="logout-btn">Logout</button></a>
</header>
</head>
<style>

h2 {
  padding-bottom: 20px;
}

</style>

<body>

  <div class="main">

 

    <div class="b1">

      <?php
require('readuser.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
      
      <h2><?php echo $results['firstname']; ?> <?php echo $results['middlename']; ?> <?php echo $results['lastname']; ?><?php } ?></h2> 





      <?php
require('readuserbalance.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
      
      <h2><i>Balance: ₱ <?php echo $results['currentfunds']; ?></i></h2>
    <?php } ?> 

      <table class="box1">
       
    
        
        <tr>
          <th>transacID</th>
          <th>Date</th>
          <th>Description</th>
          <th>Debit</th>
          <th>Credit</th>
          
        </tr>
        <tr>
<?php
require('readborrowamount.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td>Borrow ID - <?php echo $results['borrowID']; ?></td> 
          <td><?php echo $results['date']; ?></td> 
          <td><?php echo $results['bdescription']; ?></td> 
          <td></td>
          <td>₱<?php echo $results['amount']; ?></td> 
          
          
        </tr><?php } ?>

<?php
require('readlendamount.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td>Lend ID - <?php echo $results['lendid']; ?></td> 
          <td><?php echo $results['recievedate']; ?></td> 
          <td><?php echo $results['ldescription']; ?></td> 
          <td>₱<?php echo $results['lamount']; ?></td> 
          <td></td> 
          
          
        </tr><?php } ?>


        <?php
require('readpaymentactivity.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td>Payment ID - <?php echo $results['paymentid']; ?></td> 
          <td><?php echo $results['pdate']; ?></td> 
          <td><?php echo $results['pdescription']; ?></td> 
          <td>₱<?php echo $results['pamount']; ?></td> 
          <td></td> 
          
          
        </tr><?php } ?>




        <?php
require('readwithdrawactivity.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td>Withdraw ID - <?php echo $results['withdrawid']; ?></td> 
          <td><?php echo $results['releasedate']; ?></td> 
          <td><?php echo $results['wdescription']; ?></td> 
          <td></td>
          <td>₱<?php echo $results['wamount']; ?></td> 
           
          
          
        </tr><?php } ?>




      </table>
    </div>
     </div>





    </div>    
  </div>




      
     
      
    </div>
  
</body>
</html>