<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>
<!DOCTYPE html>
<html>
<head>
  <html lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="preload" href=".////css/cash.css" as="style">
  <link rel="stylesheet" href=".////css/cash.css" onload="this.media='all'">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
  <header>
    <a href="index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
    <nav>
      <ul class="nav__links"> 
        <li><a href="index.php">HOME</a></li>
        <li><a class="active-header" href="activity.php">ACTIVITY</a></li>
        <li><a href="borrower-profile.php">PROFILE</a></li>
      </ul>
    </nav>
    <a class="cta" href="logout.php"><button>Logout</button></a>
  </header>

<div class="columns">
  <ul class="payment-detail">
      <li class="header">CO-MAKER</li><br>

     <div class="main">
  


<div class="create-main">
  <form class="create-main" action="/userv2/createborrowrecord.php" method="post">
      
      <input type="text" name="cm_fname" placeholder="First Name" required/><br>
      <input type="text" name="cm_mname" placeholder="Middle Name" required/><br>
      <input type="text" name="cm_lname" placeholder="Last Name" required/><br>
      <input type="number" name="houseno" placeholder="House No" required/><br>
      <input type="text" name="street" placeholder="Street" required/><br>
      <input type="text" name="barangay" placeholder="Barangay" required/><br>
      <input type="text" name="city" placeholder="City" required/><br>
      <input type="text" name="province" placeholder="Province" required/><br>
      <input type="number" name="contactnumber" placeholder="Contact" required/><br>
      
      <input type="submit" class="contbutton" name="create" value="ADD">

    </form>

  </div>







  </div>


</div>

    
</div>
    </ul>

</div>

</body>
</html>