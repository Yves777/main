<?php 
  require('./database.php');

 
$id = $_SESSION['idnumber'];

  $queryAccounts = "select * FROM payment_record inner join borrow_record on borrow_record.borrowID = payment_record.borrowid where borrow_record.idnumber = '$id'";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
 

?>