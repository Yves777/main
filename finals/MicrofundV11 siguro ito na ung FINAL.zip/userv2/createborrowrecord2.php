<?php 
  require('./database.php');

  if (isset($_POST["create"])) {


    $idnumber = $_POST['idnumber'];
    $comakerid = $_POST['comakerid'];
    $amount = $_POST['amount'];
    $date = $_POST['date'];
    $promisedate = $_POST['promisedate'];
    $method = $_POST['method'];
    $status = $_POST['status'];
    $bdescription = $_POST['bdescription'];
    
    
    


    $queryCreate = "INSERT INTO borrow_record VALUES (null, '$idnumber', '$comakerid', '$amount', '$date', '$promisedate', '$method', '$status', '$bdescription')";
    $sqlCreate = mysqli_query($connection, $queryCreate);

    echo '<script>alert("Successfull created!")</script>';
    echo '<script>window.location.href = "/userv2/activity.php"</script>';
    
    
  } else {
    echo '<script>alert("Error!")</script>';
    
  }
?>