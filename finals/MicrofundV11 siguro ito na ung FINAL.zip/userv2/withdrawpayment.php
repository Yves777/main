<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>
<!DOCTYPE html>
<html>
<head>
	<html lang="en">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="preload" href=".////css/cash.css" as="style">
	<link rel="stylesheet" href=".////css/cash.css" onload="this.media='all'">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<style>
  textarea {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #d1cdcd;
  border-radius: 3px;
}
</style>
<body>
	<header>
		<a href="index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
		<nav>
			<ul class="nav__links"> 
				<li><a href="index.php">HOME</a></li>
				<li><a class="active-header" href="activity.php">ACTIVITY</a></li>
				<li><a href="borrower-profile.php">PROFILE</a></li>
			</ul>
		</nav>
		<a class="cta" href="logout.php"><button>Logout</button></a>
	</header>

<div class="columns">
 	<ul class="payment-detail">
	    <li class="header">WITHDRAW RECORD</li><br>
	   

	   
<div class="main">



<div class="create-main">
  <form class="create-main" action="/userv2/createwithdrawrecord.php" method="post">


  	 <?php include 'config.php'; ?>
      <select class="form-control" name="idnumber"     required/>
            <?php

              function idnumber(){
                $conn = DbConnect();
                $id = $_SESSION['idnumber'];
                $paces = $conn->prepare("SELECT * FROM lend_record where idnumber = '$id' limit 1 ");
                $paces->execute();

                $ans = $paces->setFetchMode(PDO::FETCH_ASSOC);

                while ($pace = $paces->fetch()) {

                  extract($pace);
                  echo "<option value='$idnumber'>$idnumber</option>";

                  # code...
                }
              }
              idnumber();
            ?>

            
            
          </select><br>
      
      

       


      <input type="number" name="wamount" placeholder="Amount" required/><br>
      <input type="date" name="releasedate" placeholder="Received Date" required/><br>
      <select class="form-control" name="method">
  <option value="CASH">CASH</option>
  <option value="GCASH">GCASH</option>
  <option value="BANK">BANK</option>
  
</select><br>
   
    <textarea type="text" name="wdescription" placeholder="Description"></textarea><br>
      
      
      <input type="submit" class="contbutton" name="create" value="ADD">
      <input type="hidden" name="status" placeholder="Received Date" required/><br>

    </form>

  </div>







  </div>


</div>









  	</ul>

</div>

</body>
</html>