<?php 
  require('./database.php');

 
$id = $_SESSION['idnumber'];

  $queryAccounts = "select * from borrow_record where idnumber = '$id' limit 1";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
 

?>