<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>
<!DOCTYPE html>
<html>
<head>
  <html lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="preload" href=".//css/cash.css" as="style">
  <link rel="stylesheet" href=".//css/cash.css" onload="this.media='all'">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<style>
  textarea {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #d1cdcd;
  border-radius: 3px;
}
</style>
<body>
  <header>
    <a href="index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
    <nav>
      <ul class="nav__links"> 
        <li><a href="index.php">HOME</a></li>
        <li><a class="active-header" href="activity.php">ACTIVITY</a></li>
        <li><a href="borrower-profile.php">PROFILE</a></li>
      </ul>
    </nav>
    <a class="cta" href="logout.php"><button>Logout</button></a>
  </header>

<div class="columns">
  <ul class="payment-detail">
      <li class="header">BORROWER PAYMENT PAYMENT DETAILS</li><br>
     


<div class="main">
  


<div class="create-main">
  <h1><center>BORROWER</center></h1>
  
  <form class="create-main" action="/userv2/createborrowrecord2.php" method="post">
      
      
       <p>User</p>



      
 <?php

require('readborrower-profile.php');

?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>



      <input type="number" name="idnumber" placeholder="idnumber" value="<?php echo $results['idnumber']; ?>" readonly><?php } ?>





       <?php include 'config.php'; ?>

  

      <p>Comaker</p>
      <select class="form-control" name="comakerid"  required/>
            <?php

              function comaker_id(){
                $conn = DbConnect();
                $id = $_SESSION['idnumber'];
                $paces = $conn->prepare("SELECT * FROM comaker ");
                $paces->execute();

                $ans = $paces->setFetchMode(PDO::FETCH_ASSOC);

                while ($pace = $paces->fetch()) {

                  extract($pace);
                  echo "<option value='$comaker_id'>$comaker_id - $cm_fname $cm_mname $cm_lname</option>";

                  # code...
                }
              }
              comaker_id();
            ?>

            
            
          </select><br><p>Amount</p>



      <input type="number" name="amount" placeholder="Amount" required/><br> <p>Date</p>
      <input type="date" name="date" placeholder="Date" required/><br><p>Promise Date</p>
      <input type="date" name="promisedate" placeholder="Promised Date" required/><br>
      <textarea type="text" name="bdescription" placeholder="Description"></textarea><br>
      <p><center>Payment</p>
      <select name="method" class="method">
  <option value="CASH">CASH</option>
  <option value="GCASH">GCASH</option>
  <option value="BANK">BANK</option></center>
  
</select><br><br><p>Status</p>

     <select name="status" class="method"> 
  <option value="PENDING">PENDING</option>
  
  
  
</select><br>
      
      
      <br><br>
      
      <input type="submit" class="contbutton" name="create" value="ADD">

    </form>

  </div>







  </div>


</div>



    
</div>
    </ul>

</div>

</body>
</html>