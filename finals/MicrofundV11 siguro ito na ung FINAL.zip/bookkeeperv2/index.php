<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>


<!DOCTYPE html>
<html>
<head>
	<html lang="en">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href=".//css/StylesH.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<header>
	<a href="/bookkeeperv2/index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
	<nav>
		<ul class="nav__links"> 
			<li><a class="active-header" href="/bookkeeperv2/index.php">HOME</a></li>
      <li><a class="active-header" href="/bookkeeperv2/profile.php">PROFILE</a></li>
      <li><a class="active-header" href="/bookkeeperv2/process.php">PROCESS</a></li>
      <li><a class="active-header" href="/bookkeeperv2/Financial-Statement.php">FINANCIAL STATEMENT</a></li>
      <li><a class="active-header" href="/bookkeeperv2/pending.php">PENDING</a></li>
      <li><a class="active-header" href="/bookkeeperv2/ledger.php">LEDGER</a></li>
			
		</ul>
	</nav>
	<a class="cta" href="logout.php"><button>Logout</button></a>
</header>
</head>
<body>
		<?php

require('readfund.php');

?>
	<div class="main">
		<div class="infobox">
			<table class="db1">
				<tr>
					<th scope="row">
						<?php
					date_default_timezone_set('Asia/Manila');
					$todays_date = date("y-m-d h:i:sa");
echo "DATE : " . date("Y/m/d") . "<br>";

?></th>
				</tr>
				<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
				<tr>


					<th scope="row">Available Funds:</th>
					<td><?php echo $results['currentfunds']; ?></td>




				</tr>
				 <?php } ?>
			</table>
		</div>

		<div class="b1">
			<table class="box1">
				<colgroup>
					<col class="box1a" span="3" />
					<col class="box1b" span="2" />
				</colgroup>
				<p>SUMMARY:</p>
				<tr>
					<th colspan="3">Information</th>
					<th colspan="2">Current Balance</th>
				</tr>
				<tr>
					<th scope="col">Name</th>
					<th scope="col">Email</th>
					<th scope="col">Contact Number</th>
					<th scope="col">Amount Borrowed</th>
					<th scope="col">Amount Lent</th>
				</tr>
				<tr>
					<?php

require('readamountsummary.php');


?>

 <?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
					<td><?php echo $results['firstname']; ?> <?php echo $results['middlename']; ?> <?php echo $results['lastname']; ?></td>
					<td><?php echo $results['emailaddress']; ?></td>
					<td><?php echo $results['contactnumber']; ?></td>
					<td><?php echo $results['amount']; ?></td>
					<td><?php echo $results['lamount']; ?></td>
				</tr>
				<?php } ?>
			</table>
		</div>
</body>
</html>