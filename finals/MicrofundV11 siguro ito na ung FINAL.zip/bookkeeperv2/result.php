<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>


<!DOCTYPE html>
<html>
<head>
	<html lang="en">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href=".//css/StylesH.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<header>
	<a href="/bookkeeperv2/index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
	<nav>
		<ul class="nav__links"> 
			<li><a class="active-header" href="/bookkeeperv2/index.php">HOME</a></li>
      <li><a class="active-header" href="/bookkeeperv2/profile.php">PROFILE</a></li>
      <li><a class="active-header" href="/bookkeeperv2/process.php">PROCESS</a></li>
      <li><a class="active-header" href="/bookkeeperv2/Financial-Statement.php">FINANCIAL STATEMENT</a></li>
      <li><a class="active-header" href="/bookkeeperv2/pending.php">PENDING</a></li>
      <li><a class="active-header" href="/bookkeeperv2/ledger.php">LEDGER</a></li>
			
		</ul>
	</nav>
	<a class="cta" href="logout.php"><button>Logout</button></a>
</header>
</head>
<style>
	
	.container1 input[type=text] {
  
  padding: 6px;
  margin-top: 50px;
  margin-right: auto;
  margin-left: auto;
  border: none;
  font-size: 17px;
  width: 20%;

}

.container1 button {
	font-size: 17px;
	padding: 13px;
	border: none;
}


.container1 button:hover {
	color: white;
	background: #3CB371;
}
.container1 form {
	text-align: center;
}

  
  .topnav input[type=text] {
    border: 2px solid #ccc;  
  }

   .container1 input[type=text] {
    border: 2px solid #ccc;  
  }
  .container1 {
  	margin-top: 90px;
  }



 .b1 {
  width: 100%;
  margin-top: 30px;
}

.b1 h2 {
  margin-left: 390px;
  margin-bottom: 0;
  font-weight: 650;
  font-size: 19px;
  color: #0d0d0d;
}

.box1 {
  margin: auto;
}

.box1 th {
  border: 2px solid gray;
  background-color: #0d0d0d;
  padding: 15px;
  color: #e6e6e6;
}

.box1 td, .box1 tr {
  border: 2px solid gray;
  background-color: #e3e4e3;
  width: 30%;
  padding: 15px;
  font-weight: 450;
}

.b2 {
  width: 100%;
  margin-top: 40px;
}

.main h2 {
  text-align: center;
  margin-bottom: 0;
  font-weight: 650;
  font-size: 19px;
  color: #0d0d0d;
}

.box1 h2 {
  text-align: center;
  margin-bottom: 0;
  font-weight: 650;
  font-size: 19px;
  color: #0d0d0d;
}
.box2 {
  margin: auto;
}

.box2 th {
  border: 2px solid gray;
  background-color: #0d0d0d;
  padding: 15px;
  color: #e6e6e6;
}

.box2 td, .box2 tr {
  border: 2px solid gray;
  background-color: #e3e4e3;
  width: 20%;
  padding: 15px;
  font-weight: 450;
}
.balance {
  float: right;
  margin-right: 10%;

}

.bal {
  float: left;
  margin-left: 10%;
  font-size: 20px;
}


</style>
<body>




	<div class="main">
	

		<div class="container1">
			<form action="result.php" method ="post">
			<input type="text" name="search" placeholder="Search.." required>
			<button type="submit" name="submit">Submit</button>




 <?php

$con = new PDO("mysql:host=localhost;dbname=microfundv2",'root','');

if (isset($_POST["submit"])) {
    $str = $_POST["search"];
    $sth = $con->prepare("SELECT * FROM user WHERE idnumber = '$str' ");

    $sth->setFetchMode(PDO:: FETCH_OBJ);
    $sth -> execute();

    if($row = $sth->fetch())
    {
        ?>
        <br><br><br>
        



 <div class="main">

 

    <div class="b1">

      <?php
require('readuser.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
      <div class="bal">
      <?php echo $results['firstname']; ?> <?php echo $results['middlename']; ?> <?php echo $results['lastname']; ?></div><?php } ?> 





      <?php
require('readuserbalance.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
      <div class="balance">
      <h2>Balance: ₱ <?php echo $results['currentfunds']; ?></h2></div>
    <?php } ?> 

      <table class="box1">
       
    
        
        <tr>
          <th>transacID</th>
          <th>Date</th>
          <th>Description</th>
          <th>Debit</th>
          <th>Credit</th>
          
        </tr>
        <tr>
<?php
require('readborrowamount.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td>Borrow ID - <?php echo $results['borrowID']; ?></td> 
          <td><?php echo $results['date']; ?></td> 
          <td><?php echo $results['bdescription']; ?></td> 
          <td></td>
          <td>₱<?php echo $results['amount']; ?></td> 
          
          
        </tr><?php } ?>

<?php
require('readlendamount.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td>Lend ID - <?php echo $results['lendid']; ?></td> 
          <td><?php echo $results['recievedate']; ?></td> 
          <td><?php echo $results['ldescription']; ?></td> 
          <td>₱<?php echo $results['lamount']; ?></td> 
          <td></td> 
          
          
        </tr><?php } ?>


        <?php
require('readpaymentactivity.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td>Payment ID - <?php echo $results['paymentid']; ?></td> 
          <td><?php echo $results['pdate']; ?></td> 
          <td><?php echo $results['pdescription']; ?></td> 
          <td>₱<?php echo $results['pamount']; ?></td> 
          <td></td> 
          
          
        </tr><?php } ?>




        <?php
require('readwithdrawactivity.php');
?>
<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td>Withdraw ID - <?php echo $results['withdrawid']; ?></td> 
          <td><?php echo $results['releasedate']; ?></td> 
          <td><?php echo $results['wdescription']; ?></td> 
          <td></td>
          <td>₱<?php echo $results['wamount']; ?></td> 
           
          
          
        </tr><?php } ?>




      </table>
    </div>
     </div>





    </div>    
  </div>
















        <?php 
    }
        
        
        else{
        	echo '<script>alert("Search not found!")</script>';
    echo '<script>window.location.href = "ledger.php"</script>';
            
        }


}

?>



			
			</form>	
			
		</div>

		



		
	</div>




		
</body>
</html>