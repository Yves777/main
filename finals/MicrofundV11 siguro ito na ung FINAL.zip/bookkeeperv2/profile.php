<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>

<!DOCTYPE html>
<html>
<head>
	<html lang="en">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href=".//css/indexx.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<header>
	<a href="/bookkeeperv2/index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
	<nav>
		<ul class="nav__links"> 
			<li><a class="active-header" href="/bookkeeperv2/index.php">HOME</a></li>
      <li><a class="active-header" href="/bookkeeperv2/profile.php">PROFILE</a></li>
      <li><a class="active-header" href="/bookkeeperv2/process.php">PROCESS</a></li>
      <li><a class="active-header" href="/bookkeeperv2/Financial-Statement.php">FINANCIAL STATEMENT</a></li>
      <li><a class="active-header" href="/bookkeeperv2/pending.php">PENDING</a></li>
      <li><a class="active-header" href="/bookkeeperv2/ledger.php">LEDGER</a></li>
			
		</ul>
	</nav>
	<a class="cta" href="/logout.php"><button>Logout</button></a>
</header>
</head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<body>



<script src="js/jquery-latest.min.js"></script>
<script>
	$(document).ready(function () {
		$(document.body).on("click", "th[data-href]", function () {
			window.location.href = this.dataset.href;
		});
	});
</script>

<?php

require('./read.php');

?>
<div class="main">
	<div class="contributor">
		<h1>Contributor/Borrower<a class="addbutton" href="/bookkeeperv2/add.php">ADD</a></h1>

		
<table class="contributortable">
      <tr>
        <th>ID</th>
        <th>First Name</th>
        <th>Middle Name</th>
        <th>Last Name</th>
        <th>House No.</th>
        <th>Street</th>
        <th>Barangay</th>
        <th>City</th>
        <th>Province</th>
        <th>Contact Number</th>
        <th>Email Address</th>
        <th>Password</th>
        <th>Borrow Balance</th>
        <th>Contribution Balance</th>
        
        <th>Action</th>
      </tr>
      <?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
      <tr>
      	<td><?php echo $results['idnumber']; ?></td>
        <td><?php echo $results['firstname']; ?></td>
        <td><?php echo $results['middlename']; ?></td>
        <td><?php echo $results['lastname']; ?></td>
        <td><?php echo $results['houseno']; ?></td>
        <td><?php echo $results['street']; ?></td>
        <td><?php echo $results['barangay']; ?></td>
        <td><?php echo $results['city']; ?></td>
        <td><?php echo $results['province']; ?></td>
        <td><?php echo $results['contactnumber']; ?></td>
        <td><?php echo $results['emailaddress']; ?></td>
        <td><?php echo $results['password']; ?></td>
        <td><?php echo $results['borrowbalance']; ?></td>
        <td><?php echo $results['contributionbalance']; ?></td>
        

        
      	

      	<td>
            <form action="/bookkeeperv2/update.php" method="post">
              <input type="submit" class="action" id="action" name="edit" value="UPDATE" />
              <input type="hidden" name="editidnumber" value="<?php echo $results['idnumber'] ?>" />
              <input type="hidden" name="editfirstname" value="<?php echo $results['firstname'] ?>" />
              <input type="hidden" name="editmiddlename" value="<?php echo $results['middlename'] ?>" />
              <input type="hidden" name="editlastname" value="<?php echo $results['lastname'] ?>" />
              <input type="hidden" name="edithouseno" value="<?php echo $results['houseno'] ?>" />
              <input type="hidden" name="editstreet" value="<?php echo $results['street'] ?>" />
              <input type="hidden" name="editbarangay" value="<?php echo $results['barangay'] ?>" />
              <input type="hidden" name="editcity" value="<?php echo $results['city'] ?>" />
              <input type="hidden" name="editprovince" value="<?php echo $results['province'] ?>" />
              <input type="hidden" name="editcontactnumber" value="<?php echo $results['contactnumber'] ?>" />
              <input type="hidden" name="editemailaddress" value="<?php echo $results['emailaddress'] ?>" />
              <input type="hidden" name="editpassword" value="<?php echo $results['password'] ?>" />
              <input type="hidden" name="editborrowbalance" value="<?php echo $results['borrowbalance'] ?>" />
              <input type="hidden" name="editcontributionbalance" value="<?php echo $results['contributionbalance'] ?>" />
              
              
              
              
            </form>
           
          </td>
      </tr>
		
	</div>
  <?php } ?>
  
</table>







	</div>


</div>






</body>

</html>


