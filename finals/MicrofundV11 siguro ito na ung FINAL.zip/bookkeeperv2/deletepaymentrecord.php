<?php 
  require('./database.php');

  if (isset($_POST["delete"])) {
    $deleteId = $_POST['deleteId'];

    $queryDelete = "DELETE FROM payment_record WHERE paymentid = $deleteId";
    $sqlDelete = mysqli_query($connection, $queryDelete);

    echo '<script>alert("Successfull deleted id!")</script>';
    echo '<script>window.location.href = "/bookkeeperv2/process.php"</script>';
  } else {
    echo '<script>window.location.href = "/bookkeeperv2/process.php"</script>';
  }
?>