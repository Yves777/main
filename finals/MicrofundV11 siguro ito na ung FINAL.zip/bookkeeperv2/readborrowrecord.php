<?php 
  require('./database.php');
 

  $queryAccounts = "SELECT * FROM borrow_record inner join comaker on comaker.comaker_id = borrow_record.comakerid inner join user on borrow_record.idnumber = user.idnumber order by borrow_record.borrowID desc";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
?>