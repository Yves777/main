<?php 
  require('./database.php');

  if (isset($_POST["create"])) {


    $idnumber = $_POST['idnumber'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $houseno = $_POST['houseno'];
    $street = $_POST['street'];
    $barangay = $_POST['barangay'];
    $city = $_POST['city'];
    $province = $_POST['province'];
    $contactnumber = $_POST['contactnumber'];
    $emailaddress = $_POST['emailaddress'];
    $password = $_POST['password'];
    $borrowbalance = $_POST['borrowbalance'];
    $contributionbalance = $_POST['contributionbalance'];
    $access_level = $_POST['access_level'];
    
    
    


    $queryCreate = "INSERT INTO user VALUES ('$idnumber', '$firstname', '$middlename', '$lastname', '$houseno', '$street', '$barangay', '$city', '$province', '$contactnumber', '$emailaddress', '$password', '$borrowbalance', '$contributionbalance', '$access_level')";
    $sqlCreate = mysqli_query($connection, $queryCreate);

    echo '<script>alert("Successfull created!")</script>';
    echo '<script>window.location.href = "/bookkeeperv2/profile.php"</script>';
    
  } else {
    echo '<script>alert("Error!")</script>';
    
  }
?>