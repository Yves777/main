<?php 
  require('./database.php');

 


  $queryAccounts = "select * FROM payment_record inner join borrow_record on borrow_record.borrowID = payment_record.borrowid where borrow_record.idnumber = '$str'";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
 

?>