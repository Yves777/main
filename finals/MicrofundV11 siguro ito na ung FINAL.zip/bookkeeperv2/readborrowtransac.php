<?php 
  require('./database.php');

 

  $queryAccounts = "SELECT * FROM borrow_record";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);


?>