<?php 
  require('./database.php');

  if (isset($_POST["create"])) {


    $cm_fname = $_POST['cm_fname'];
    $cm_mname = $_POST['cm_mname'];
    $cm_lname = $_POST['cm_lname'];
    $houseno = $_POST['houseno'];
    $street = $_POST['street'];
    $barangay = $_POST['barangay'];
    $city = $_POST['city'];
    $province = $_POST['province'];
    $contactnumber = $_POST['contactnumber'];
    
    
    


    $queryCreate = "INSERT INTO comaker VALUES (null, '$cm_fname', '$cm_mname', '$cm_lname', '$houseno', '$street', '$barangay', '$city', '$province', '$contactnumber')";
    $sqlCreate = mysqli_query($connection, $queryCreate);

    echo '<script>alert("Successfull created!")</script>';
    echo '<script>window.location.href = "/bookkeeperv2/addborrowrecord2.php"</script>';
    
    
  } else {
    echo '<script>alert("Error!")</script>';
    
  }
?>