<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>

<!DOCTYPE html>
<html>
<head>
	<html lang="en">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href=".//css/indexx.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<header>
	<a href="/bookkeeperv2/index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
	<nav>
		<ul class="nav__links"> 
			<li><a class="active-header" href="/bookkeeperv2/index.php">HOME</a></li>
      <li><a class="active-header" href="/bookkeeperv2/profile.php">PROFILE</a></li>
      <li><a class="active-header" href="/bookkeeperv2/process.php">PROCESS</a></li>
      <li><a class="active-header" href="/bookkeeperv2/Financial-Statement.php">FINANCIAL STATEMENT</a></li>
      <li><a class="active-header" href="/bookkeeperv2/pending.php">PENDING</a></li>
      <li><a class="active-header" href="/bookkeeperv2/ledger.php">LEDGER</a></li>
			
		</ul>
	</nav>
	<a class="cta" href="/logout.php"><button>Logout</button></a>

</header>
</head>
<style>
  .main img {
    display: block;
    margin-left: auto;
    margin-right: auto;
    height: 27vh;
  }

.main {
  text-align: center;
}

.main input {
  width: 20%;
  padding: 15px;
  text-align: center;
  font-size: 20px;
}

.main select {
  width: 22%;
  padding: 15px;
  text-align: center;
  font-size: 20px;
}
.contbutton {
  color: white;
  background: #111;
}

.contbutton:hover {
  background-color: green;

}


</style>
<body>



<script src="js/jquery-latest.min.js"></script>
<script>
	$(document).ready(function () {
		$(document.body).on("click", "th[data-href]", function () {
			window.location.href = this.dataset.href;
		});
	});
</script>

<div class="main">
	
<img src="./image/user3.jfif">

<div class="create-main">
  <h1><center>CO-MAKER</center></h1>
  
  <form class="create-main" action="/bookkeeperv2/createborrowrecord.php" method="post">
      
      <input type="text" name="cm_fname" placeholder="First Name" required/><br>
      <input type="text" name="cm_mname" placeholder="Middle Name" required/><br>
      <input type="text" name="cm_lname" placeholder="Last Name" required/><br>
      <input type="number" name="houseno" placeholder="House No" required/><br>
      <input type="text" name="street" placeholder="Street" required/><br>
      <input type="text" name="barangay" placeholder="Barangay" required/><br>
      <input type="text" name="city" placeholder="City" required/><br>
      <input type="text" name="province" placeholder="Province" required/><br>
      <input type="number" name="contactnumber" placeholder="Contact" required/><br>
      
      <br><br>
      
      <input type="submit" class="contbutton" name="create" value="ADD">

    </form>

  </div>







	</div>


</div>





</body>
</html>
