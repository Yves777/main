<?php 
  require('./database.php');

 

  $queryAccounts = "SELECT * FROM user where access_level = 2";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);


?>