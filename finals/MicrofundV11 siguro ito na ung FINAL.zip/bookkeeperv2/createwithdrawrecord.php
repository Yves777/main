<?php 
  require('./database.php');

  if (isset($_POST["create"])) {


    $idnumber = $_POST['idnumber'];
    $wamount = $_POST['wamount'];
    $releasedate = $_POST['releasedate'];
    $method = $_POST['method'];
    $status = $_POST['status'];
    $description = $_POST['description'];
    
    
    
    
    


    $queryCreate = "INSERT INTO withdraw_record VALUES (null, '$idnumber', '$wamount', '$releasedate', '$method', '$status', '$description')";
    $sqlCreate = mysqli_query($connection, $queryCreate);

    echo '<script>alert("Successfull created!")</script>';
    echo '<script>window.location.href = "/bookkeeperv2/process.php"</script>';
    
    
  } else {
    echo '<script>alert("Error!")</script>';
    
  }
?>