<?php 
  require('./database.php');
 

  $queryAccounts = "SELECT * FROM lend_record inner join user on lend_record.idnumber = user.idnumber order by lendid desc ";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
?>