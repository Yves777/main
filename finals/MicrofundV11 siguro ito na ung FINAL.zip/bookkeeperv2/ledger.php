<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>


<!DOCTYPE html>
<html>
<head>
	<html lang="en">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href=".//css/StylesH.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<header>
	<a href="/bookkeeperv2/index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
	<nav>
		<ul class="nav__links"> 
			<li><a class="active-header" href="/bookkeeperv2/index.php">HOME</a></li>
      <li><a class="active-header" href="/bookkeeperv2/profile.php">PROFILE</a></li>
      <li><a class="active-header" href="/bookkeeperv2/process.php">PROCESS</a></li>
      <li><a class="active-header" href="/bookkeeperv2/Financial-Statement.php">FINANCIAL STATEMENT</a></li>
      <li><a class="active-header" href="/bookkeeperv2/pending.php">PENDING</a></li>
      <li><a class="active-header" href="/bookkeeperv2/ledger.php">LEDGER</a></li>
			
		</ul>
	</nav>
	<a class="cta" href="logout.php"><button>Logout</button></a>
</header>
</head>
<style>
.container1 input[type=text] {
  
  padding: 6px;
  margin-top: 50px;
  margin-right: auto;
  margin-left: auto;
  border: none;
  font-size: 17px;
  width: 20%;

}

.container1 button {
	font-size: 17px;
	padding: 13px;
	border: none;
}


.container1 button:hover {
	color: white;
	background: #3CB371;
}
.container1 form {
	text-align: center;
}

  
  .topnav input[type=text] {
    border: 2px solid #ccc;  
  }

   .container1 input[type=text] {
    border: 2px solid #ccc;  
  }
  .container1 {
  	margin-top: 90px;
  }

</style>
<body>


<div class="container1">
			<form action="result.php" method ="post">
			<input type="text" name="search" placeholder="Search..">
			<button type="submit" name="submit">Submit</button>








			
			</form>	
			
		</div>



		
</body>
</html>