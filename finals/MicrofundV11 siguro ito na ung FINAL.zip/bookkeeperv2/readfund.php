<?php 
  require('./database.php');
 

  $queryAccounts = "SELECT 
    ((SELECT coalesce(SUM(lamount),0) FROM lend_record) + 
    (SELECT coalesce(SUM(pamount),0) FROM payment_record)) -
    ((SELECT coalesce(SUM(amount),0) FROM borrow_record) +
    (SELECT coalesce(SUM(wamount),0) FROM withdraw_record)) as currentfunds ";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
?>