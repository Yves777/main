<?php 
  require('./database.php');

 

  $queryAccounts = "SELECT * FROM withdraw_record";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);


?>