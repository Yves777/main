<?php 
  require('./database.php');

  if (isset($_POST["edit"])) {
    $editidnumber = $_POST['editidnumber'];
    $editfirstname = $_POST['editfirstname'];
    $editmiddlename = $_POST['editmiddlename'];
    $editlastname = $_POST['editlastname'];
    $edithouseno = $_POST['edithouseno'];
    $editstreet = $_POST['editstreet'];
    $editbarangay = $_POST['editbarangay'];
    $editcity = $_POST['editcity'];
    $editprovince = $_POST['editprovince'];
    $editcontactnumber = $_POST['editcontactnumber'];
    $editemailaddress = $_POST['editemailaddress'];
    $editpassword= $_POST['editpassword'];
    $editborrowbalance= $_POST['editborrowbalance'];
    $editcontributionbalance= $_POST['editcontributionbalance'];
    

    
    
    

  }

  if (isset($_POST['update'])) {

    $updateidnumber = $_POST['updateidnumber'];
    $updatefirstname = $_POST['updatefirstname'];
    $updatemiddlename = $_POST['updatemiddlename'];
    $updatelastname = $_POST['updatelastname'];
    $updatehouseno = $_POST['updatehouseno'];
    $updatestreet = $_POST['updatestreet'];
    $updatebarangay = $_POST['updatebarangay'];
    $updatecity = $_POST['updatecity'];
    $updateprovince = $_POST['updateprovince'];
    $updatecontactnumber = $_POST['updatecontactnumber'];
    $updateemailaddress = $_POST['updateemailaddress'];
    $updatepassword = $_POST['updatepassword'];
    $updateborrowbalance = $_POST['updateborrowbalance'];
    $updatecontributionbalance = $_POST['updatecontributionbalance'];

    

    

    

    

    $queryUpdate = "UPDATE user SET firstname = '$updatefirstname', middlename = '$updatemiddlename', lastname = '$updatelastname', houseno = '$updatehouseno', street = '$updatestreet', barangay = '$updatebarangay', city = '$updatecity', province = '$updateprovince', contactnumber = '$updatecontactnumber', emailaddress = '$updateemailaddress', password = '$updatepassword', borrowbalance = '$updateborrowbalance', contributionbalance = '$updatecontributionbalance' WHERE idnumber = $updateidnumber";
    $sqlUpdate = mysqli_query($connection, $queryUpdate);

    echo '<script>alert("Successfully updated!")</script>';
    echo '<script>window.location.href = "/bookkeeperv2/profile.php"</script>';
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  
  <title>Update</title>



</head>
<style>
  
.main {
  height: 100vh;
  padding: 20px 12px 10px 20px;
  text-align: center;
  font-weight: 800;
}

.main .heading{
  font-weight: bold;
  border-bottom: 2px solid #ddd;
  margin-bottom: 20px;
  font-size: 20px;
  font-style: italic;
  padding-bottom: 3px;
}

.update-main label{
  display: block;
  margin-top: 20px;
}

.update-main .cno,
.update-main .uid {
  text-align: center;
}

.update-main input.fieldtext,  {
  width: 48%; 
}

.update-main input.fieldtext, 
.update-main input.cno, 
.update-main input.uid{
  border: 1px solid #C2C2C2;
  border-radius: 3px;
  padding: 7px;
  outline: none;
  text-align: center;
}

.submit {
  margin-top: 30px;
  font-weight: bold;
}
</style>

<body>
<div class="main">
  <div class="heading"> UPDATE USER</div>
    <form class="update-main" action="/bookkeeperv2/update.php" method="post">

    

      <label for="firstname">First Name</label>
      <input type="text" class="fieldtext" name="updatefirstname" placeholder="First Name" value="<?php echo $editfirstname?>" required/>

      <label for="middlename">Middle Name</label>
      <input type="text" class="fieldtext" name="updatemiddlename" placeholder="Middle Name" value="<?php echo $editmiddlename?>" required/>

      <label for="lastname">Last Name</label>
      <input type="text" class="fieldtext" name="updatelastname" placeholder="Last Name" value="<?php echo $editlastname?>" required/>

      <label for="houseno">House No</label>
      <input type="text" class="fieldtext" name="updatehouseno" placeholder="House No" value="<?php echo $edithouseno?>" required/>

      <label for="street">Street</label>
      <input type="text" class="fieldtext" name="updatestreet" placeholder="Street" value="<?php echo $editstreet?>" required/>

      <label for="barangay">Barangay</label>
      <input type="text" class="fieldtext" name="updatebarangay" placeholder="Barangay" value="<?php echo $editbarangay?>" required/>

      <label for="city">City</label>
      <input type="text" class="fieldtext" name="updatecity" placeholder="City" value="<?php echo $editcity?>" required/>

      <label for="province">Province</label>
      <input type="text" class="fieldtext" name="updateprovince" placeholder="Province" value="<?php echo $editprovince?>" required/>

      <label for="contactnumber">Contact Number</label>
      <input type="text" class="fieldtext" name="updatecontactnumber" placeholder="Contact Number" value="<?php echo $editcontactnumber?>" required/>

      <label for="emailaddress">Email Address</label>
      <input type="text" class="fieldtext" name="updateemailaddress" placeholder="Email Address" value="<?php echo $editemailaddress?>" required/>

      <label for="password">Password</label>
      <input type="text" class="fieldtext" name="updatepassword" placeholder="Password" value="<?php echo $editpassword?>" required/>

      <label for="borrowbalance">Borrow Balance</label>
      <input type="text" class="fieldtext" name="updateborrowbalance" placeholder="Borrow Balance" value="<?php echo $editborrowbalance?>" required/>

      <label for="contributionbalance">Contribution Balance</label>
      <input type="text" class="fieldtext" name="updatecontributionbalance" placeholder="Contribution Balance" value="<?php echo $editcontributionbalance?>" required/>

     

     




      <br> 

      <div class="submit">
        <input type="submit" name="update" value="UPDATE" />
        <input type="hidden" name="updateidnumber" value="<?php echo $editidnumber ?>" />
        
      </div>
    </form>
</body>
</html>