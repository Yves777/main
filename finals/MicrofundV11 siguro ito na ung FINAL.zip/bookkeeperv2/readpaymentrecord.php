<?php 
  require('./database.php');
 

  $queryAccounts = "SELECT * FROM payment_record inner join borrow_record on borrow_record.idnumber = payment_record.idnumber inner join user on payment_record.idnumber = user.idnumber order by payment_record.paymentid desc";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
?>