<?php 
  require('./database.php');

 

  $queryAccounts = "SELECT * from user A left join borrow_record B on A.idnumber=B.idnumber left join lend_record C on A.idnumber=C.idnumber  ";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);


?>