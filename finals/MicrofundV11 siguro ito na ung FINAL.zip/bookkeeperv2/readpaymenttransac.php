<?php 
  require('./database.php');



  $queryAccounts = "select * FROM payment_record inner join image where payment_record.paymentid = image.paymentid";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);


?>