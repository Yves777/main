<?php 
  require('./database.php');

  if (isset($_POST["delete"])) {
    $deleteId = $_POST['deleteId'];

    $queryDelete = "DELETE FROM user WHERE idnumber = $deleteId";
    $sqlDelete = mysqli_query($connection, $queryDelete);

    echo '<script>alert("Successfull deleted id!")</script>';
    echo '<script>window.location.href = "/bookkeeperv2/profile.php"</script>';
  } else {
    echo '<script>("Error!")</script>';
  }
?>