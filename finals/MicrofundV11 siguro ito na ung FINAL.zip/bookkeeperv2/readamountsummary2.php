<?php 
  require('./database.php');

 

  $queryAccounts = "SELECT * FROM user inner join lend_record on user.idnumber = lend_record.idnumber ";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);


?>