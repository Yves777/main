<?php 
  require('./database.php');

 


  $queryAccounts = "select * from lend_record where idnumber = '$str'";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
 

?>