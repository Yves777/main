<?php 
  require('./database.php');

 


  $queryAccounts = "select * from user where idnumber = '$str' ";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
 
?>