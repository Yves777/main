<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>
<!DOCTYPE html>
<html>
<head>

	<html lang="en">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<header>
	<style>
.divTableRow{
	margin: 10px;
	width: 100%;
}

table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
h2{
	font-family: arial, sans-serif;
	margin: 10px;
}

.divTableCell button a{
	color: white;
}


/*start*/

body {
  margin: 0;
}


h1 {
  font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
  
  
}


li, a, button {
  font-weight: 500;
  font-size: 18px;
  text-decoration: none;
}

a {
  color: #2196F3;
}

header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px ;
  background-color: #363633;
}


.active-header {
  background-color: #363633;
  color: #ffffff;
  padding: 30px 35px;
}

.logo {
  cursor: pointer;
  height: 30px;
  width: 90px;
  
}


.nav__links {
  list-style: none;
}

.nav__links li {
  display: inline-block;
  
}



.nav__links li a:hover {
  background-color: black;
  
}



button {
  color: #ffffff;
  padding: 9px 25px;
  background-color: #0099f7;
  border: none;
  border-radius: 50px;
  cursor: pointer;
  transition: all 0.3s ease 0s; 
}

button:hover {
  background-color: #c6f1f5;
  color: #000000;
}

.main {
  padding: 5%;
}

.main .contributortable {
  text-align: center;
  font-size: 20px;
  padding: 25px 50px; 
  border-style: solid;
  width: 100%;
  border-color: green ;
  font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
   
}

.main .contributortable tr th {
  padding: 10px;
}

.action {
  color: white;
}

#action {
  width: 10vh;
  background-color:#111;
  
}

#action:hover {
  
  background-color: green;
}

.actiond {
  color: white;
}

#actiond {
  width: 10vh;
  background-color:#111;
  
}

#actiond:hover {
  
  background-color: red;
}
.addbutton {
  
  float: right;
  margin-right: 80%;
  border-style: solid;
  border-color: black;
  font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
  padding: 10px 50px;
  font-size: 20px;;
  
  
}

.addbutton:hover {
  background-color: green;
  color: white;
}

td{
  padding: 5px;
}

.addbutton {
	text-align: center;
}

input[type=submit]:hover{
	 background-color: green;
     color: white;
}



</style>
	<a href="/bookkeeperv2/index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
	<nav>
		<ul class="nav__links"> 
			<li><a class="active-header" href="/bookkeeperv2/index.php">HOME</a></li>
      <li><a class="active-header" href="/bookkeeperv2/profile.php">PROFILE</a></li>
      <li><a class="active-header" href="/bookkeeperv2/process.php">PROCESS</a></li>
      <li><a class="active-header" href="/bookkeeperv2/Financial-Statement.php">FINANCIAL STATEMENT</a></li>
      <li><a class="active-header" href="/bookkeeperv2/pending.php">PENDING</a></li>
      <li><a class="active-header" href="/bookkeeperv2/ledger.php">LEDGER</a></li>
			
		</ul>
	</nav>
	<a class="cta" href="logout.php"><button>Logout</button></a>
</header>
</head>

<body>
	<?php

require('readborrowrecord.php');

?>
	
<div class="divTableRow">
	<h2>Borrow Record</h2>
			<div class="divTableCell"><button><a href="addborrowrecord.php">Add</a></button>
				

<table class="contributortable">
      <tr>
        <th>BORROW ID</th>
        <th>ID NUMBER</th>
        <th>DATE</th>
        <th>AMOUNT</th>
        <th>PROMISE TO PAY DATE</th>
        <th>CO-MAKER</th>
        <th>CO-MAKER CONTACT #</th>
        <th>METHOD</th>
        <th>DESCRIPTION</th>
        <th>Action</th>
        
      </tr>
      <?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
      <tr>
      	<td><?php echo $results['borrowID']; ?></td>
        <td><?php echo $results['idnumber']; ?> - <?php echo $results['firstname']; ?> <?php echo $results['middlename']; ?> <?php echo $results['lastname']; ?></td>
        <td><?php echo $results['date']; ?></td>
        <td><?php echo $results['amount']; ?></td>
        <td><?php echo $results['promisedate']; ?></td>
		<td><?php echo $results['cm_fname']; ?> <?php echo $results['cm_mname']; ?> <?php echo $results['cm_lname']; ?></td>
        <td><?php echo $results['contactnumber']; ?></td>
        <td><?php echo $results['method']; ?></td>
        <td><?php echo $results['bdescription']; ?></td>

        <td>
            <form action="/bookkeeperv2/updateborrowrecord.php" method="post">
              <input type="submit" name="edit" value="UPDATE" />
              <input type="hidden" name="editborrowID" value="<?php echo $results['borrowID'] ?>" />
              <input type="hidden" name="editidnumber" value="<?php echo $results['idnumber'] ?>" />
              <input type="hidden" name="editdate" value="<?php echo $results['date'] ?>" />
              <input type="hidden" name="editamount" value="<?php echo $results['amount'] ?>" />
              <input type="hidden" name="editpromisedate" value="<?php echo $results['promisedate'] ?>" />
              <input type="hidden" name="editcomakerid" value="<?php echo $results['comakerid'] ?>" />
              <input type="hidden" name="editbdescription" value="<?php echo $results['bdescription'] ?>" />
             
              
              
            </form>
           
        </td>
        

    </tr>
    <?php } ?>
</table>



			</div><br>
<?php

require('readpaymentrecord.php');

?>
<h2>PAYMENT RECORD</h2>
<div class="divTableCell"><button><a href="addpaymentrecord.php">Add</a></button>

<table class="contributortable2">
      <tr>
        <th>PAYMENT ID</th>
        
        <th>ID NUMBER</th>
        <th>DATE</th>
        <th>AMOUNT</th>
        <th>METHOD</th>
        <th>DESCRIPTION</th>
        <th>Action</th>

        
        
      </tr>
      <?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
      <tr>
      	<td><?php echo $results['paymentid']; ?></td>
        
        <td><?php echo $results['idnumber']; ?> - <?php echo $results['firstname']; ?> <?php echo $results['middlename']; ?> <?php echo $results['lastname']; ?></td>
        <td><?php echo $results['pdate']; ?></td>
        <td><?php echo $results['pamount']; ?></td>
        <td><?php echo $results['method']; ?></td>
        <td><?php echo $results['pdescription']; ?></td>

         <td>
            <form action="/bookkeeperv2/updatepaymentrecord.php" method="post">
              <input type="submit" name="edit" value="UPDATE" />
              <input type="hidden" name="editpaymentid" value="<?php echo $results['paymentid'] ?>" />
              <input type="hidden" name="editborrowid" value="<?php echo $results['borrowid'] ?>" />
              <input type="hidden" name="editidnumber" value="<?php echo $results['idnumber'] ?>" />
              <input type="hidden" name="editpdate" value="<?php echo $results['pdate'] ?>" />
              <input type="hidden" name="editpamount" value="<?php echo $results['pamount'] ?>" />
              <input type="hidden" name="editpdescription" value="<?php echo $results['pdescription'] ?>" />
             
              
              
            </form>
            
        </td>

               

    </tr>
    <?php } ?>
</table>

			</div>



			<?php

require('readlendrecord.php');

?>
<br>
<h2>LEND RECORD</h2>
<div class="divTableCell"><button><a href="addlendrecord.php">Add</a></button>

<table class="contributortable2">
      <tr>
      	
        <th>LEND ID</th>
        <th>ID NUMBER</th>
        <th>AMOUNT</th>
        <th>RECEIVED DATE</th>
        <th>DESCRIPTION</th>
        <th>METHOD</th>
        <th>Action</th>
    </center>
        
        
      </tr>
      <?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
      <tr>
      	<td><?php echo $results['lendid']; ?></td>
        <td><?php echo $results['idnumber']; ?> - <?php echo $results['firstname']; ?> <?php echo $results['middlename']; ?> <?php echo $results['lastname']; ?></td>
        <td><?php echo $results['lamount']; ?></td>
        <td><?php echo $results['recievedate']; ?></td>
        <td><?php echo $results['ldescription']; ?></td>
        <td><?php echo $results['method']; ?></td>

        <td>
            <form action="/bookkeeperv2/updatelendrecord.php" method="post">
              <input type="submit" name="edit" value="UPDATE" />
              <input type="hidden" name="editlendid" value="<?php echo $results['lendid'] ?>" />
              <input type="hidden" name="editidnumber" value="<?php echo $results['idnumber'] ?>" />
              <input type="hidden" name="editlamount" value="<?php echo $results['lamount'] ?>" />
              <input type="hidden" name="editrecievedate" value="<?php echo $results['recievedate'] ?>" />
              <input type="hidden" name="editldescription" value="<?php echo $results['ldescription'] ?>" />
             
              
              
            </form>
           
        </td>

               

    </tr>
    <?php } ?>
</table>

			</div>




			<?php

require('readwithdrawrecord.php');

?>
<br>
<h2>WITHDRAW RECORD</h2>
<div class="divTableCell"><button><a href="addwithdrawrecord.php">Add</a></button>

<table class="contributortable2">
      <tr>
        <th>WITHDRAW ID</th>
        <th>ID NUMBER</th>
        <th>AMOUNT</th>
        <th>RELEASE DATE</th>
        <th>METHOD</th>
        <th>DESCRIPTION</th>
        <th>Action</th>
        
        
        
      </tr>
      <?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
      <tr>
      	<td><?php echo $results['withdrawid']; ?></td>
        <td><?php echo $results['idnumber']; ?> - <?php echo $results['firstname']; ?> <?php echo $results['middlename']; ?> <?php echo $results['lastname']; ?></td>
        <td><?php echo $results['wamount']; ?></td>
        <td><?php echo $results['releasedate']; ?></td>
        <td><?php echo $results['method']; ?></td>
        <td><?php echo $results['wdescription']; ?></td>

         <td>
            <form action="/bookkeeperv2/updatewithdrawrecord.php" method="post">
              <input type="submit" name="edit" value="UPDATE" />
              <input type="hidden" name="editwithdrawid" value="<?php echo $results['withdrawid'] ?>" />
              <input type="hidden" name="editidnumber" value="<?php echo $results['idnumber'] ?>" />
              <input type="hidden" name="editwamount" value="<?php echo $results['wamount'] ?>" />
              <input type="hidden" name="editreleasedate" value="<?php echo $results['releasedate'] ?>" />
              <input type="hidden" name="editwdescription" value="<?php echo $results['wdescription'] ?>" />
              
             
              
              
            </form>
          
        </td>
               

    </tr>
    <?php } ?>
</table>
<br>
			</div>
        





        </div>

</body>
</html>
