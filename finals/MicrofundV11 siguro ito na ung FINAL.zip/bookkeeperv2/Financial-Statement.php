<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>

<!DOCTYPE html>
<html>
<head>
	<html lang="en">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href=".//css/stylefs.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<header>
	<a href="/bookkeeperv2/index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
	<nav>
		<ul class="nav__links"> 
			<li><a class="active-header" href="/bookkeeperv2/index.php">HOME</a></li>
      <li><a class="active-header" href="/bookkeeperv2/profile.php">PROFILE</a></li>
      <li><a class="active-header" href="/bookkeeperv2/process.php">PROCESS</a></li>
      <li><a class="active-header" href="/bookkeeperv2/Financial-Statement.php">FINANCIAL STATEMENT</a></li>
      <li><a class="active-header" href="/bookkeeperv2/pending.php">PENDING</a></li>
      <li><a class="active-header" href="/bookkeeperv2/ledger.php">LEDGER</a></li>
			
		</ul>
	</nav>
	<a class="cta" href="/logout.php"><button>Logout</button></a>
</header>
</head>

<body>
	<div class="main">
		<div class="b1">
			<table class ="box1">
				<tr>
					<th>FINANCIAL STATEMENT AS OF DECEMBER 21, 2020</th>
				</tr>
			</table>
		</div>

		<div class="b2">
			<table class="box2">
				<tr>
					<td>Cash in Bank</td>
					<td>70000.00</td>
				</tr>
				<tr>
					<td>Cash on Hand</td>
					<td>0.00</td>
				</tr>
				<tr>
					<td></td>
					<td>0.00</td>
				</tr>
				<tr>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td>Capital</td>
					<td></td>
				</tr>
				<tr>
					<td>Initial Fund from CIS and Friends</td>
					<td>40000.00</td>
				</tr>
				<tr>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td>Liabilities</td>
					<td></td>
				</tr>
				<tr>
					<td>Entrusted Amount</td>
					<td>50000.00</td>
				</tr>
			</table>
		</div>

		<div class="b3">
			<table class="box3">
				<button class="create">Create</button>
			</table>
		</div>
	</body>
</html>