<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>


<!DOCTYPE html>
<html>
<head>
	<html lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="preload" href="./css/StylesH.css" as="style">
  <link rel="stylesheet" href="./css/StylesH.css" onload="this.media='all'">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<header>
	<a href="/bookkeeperv2/index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
	<nav>
		<ul class="nav__links"> 
			<li><a class="active-header" href="/bookkeeperv2/index.php">HOME</a></li>
      <li><a class="active-header" href="/bookkeeperv2/profile.php">PROFILE</a></li>
      <li><a class="active-header" href="/bookkeeperv2/process.php">PROCESS</a></li>
      <li><a class="active-header" href="/bookkeeperv2/Financial-Statement.php">FINANCIAL STATEMENT</a></li>
      <li><a class="active-header" href="/bookkeeperv2/pending.php">PENDING</a></li>
      <li><a class="active-header" href="/bookkeeperv2/ledger.php">LEDGER</a></li>
			
		</ul>
	</nav>
	<a class="cta" href="logout.php"><button>Logout</button></a>
</header>
</head>
<style>
	.b1 {
  width: 100%;
  margin-top: 120px;
}

.b1 p {
  margin-left: 120px;
  margin-bottom: 0px;
  font-weight: 650;
  font-size: 25px;
  color: #0d0d0d;
}

.box1 {
  margin: auto;

}

.box1 th {
    border: 2px solid gray;
    background-color: #0d0d0d;
    padding: 15px;
    color: #e6e6e6;

}

.box1 td, .box1 tr {
    border: 2px solid gray;
    background-color: #e3e4e3;
    width: 20%;
    padding: 15px;
    font-weight: 450;
    font-size: 20px;
}

.b2 {
  width: 100%;
  margin-top: 50px;
}

.box2 {
  margin: auto;
}

.b2 p {
  margin-left: 390px;
  margin-bottom: 0px;
  font-weight: 650;
  font-size: 19px;
  color: #0d0d0d;
}


.box2 th {
    border: 2px solid gray;
    background-color: #0d0d0d;
    padding: 15px;
    color: #e6e6e6;

}

.box2 td, .box2 tr {
    border: 2px solid gray;
    background-color: #e3e4e3;
    width: 20%;
    padding: 15px;
    font-weight: 450;
}

button a {
	color: white;
}

.main img {
  
   ;
  
  transition: transform 0s; /* Animation */
  
  height: 10vh;
  margin: 0 auto;
}

 td >img:hover {
  transform: scale(8.0);
  margin-right: 800px;
  margin-top: 100px;

 
  

}




	</style>
<body>

	


	<div class="main">
    <div class="b1">





      <table class="box1">
        <p>Summary</p><br>
         <tr>
          <th>ID Number</th>
          <th>Activity</th>
          <th>Amount</th>
          <th>Date</th>
          <th>Status</th>
          <th>Action</th>
          <th>Proof of Payment</th>
        
        </tr>
        
        
        <tr>
<?php

require('readpaymenttransac.php');

?>

          <?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td><?php echo $results['idnumber']; ?></td>
          <td>Payment ID : <?php echo $results['paymentid']; ?></td>
          <td><?php echo $results['pamount']; ?></td>
          <td><?php echo $results['pdate']; ?></td>
          <td><?php echo $results['pstatus']; ?></td>

          
          <td>



 <form action="/bookkeeperv2/updatepaymentrecord2.php" method="post">
              <input type="submit" name="edit" value="UPDATE" />
              <input type="hidden" name="editpaymentid" value="<?php echo $results['paymentid'] ?>" />
              <input type="hidden" name="editpstatus" value="<?php echo $results['pstatus'] ?>" />
            
              
            </form><br>


          </td>
          <td><?php echo "<img src='Image/".$results['filename']."' />"; ?></td>



         

        
        </tr><?php } ?>
      </table>
<br>






      <table class="box1">
        
        <tr>
          <th>ID Number</th>
          <th>Activity</th>
          <th>Amount</th>
          <th>Date</th>
          <th>Status</th>
          <th>Action</th>
        
        </tr>
        
<?php

require('readborrowtransac.php');

?>

        	<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td><?php echo $results['idnumber']; ?></td>
          <td>Borrow ID : <?php echo $results['borrowID']; ?></td>
          <td><?php echo $results['amount']; ?></td>
          <td><?php echo $results['date']; ?></td>
          <td><?php echo $results['status']; ?></td>
          <td> 


              <form action="/bookkeeperv2/updateborrowrecord2.php" method="post">
              <input type="submit" name="edit" value="UPDATE" />
              <input type="hidden" name="editborrowID" value="<?php echo $results['borrowID'] ?>" />
              <input type="hidden" name="editstatus" value="<?php echo $results['status'] ?>" />
              
             
              
              
            </form><br>




          	 <form action="/bookkeeperv2/deleteborrowrecord.php" method="post">
              <input type="submit" name="delete" value="DECLINE" />
              <input type="hidden" name="deleteId" value="<?php echo $results['borrowID'] ?>"/>
            </form>
          	</td>

        
        </tr><?php } ?>
      
    </div>




    

    
        
        
      
<?php

require('readlendtransac.php');

?>

        	<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td><?php echo $results['idnumber']; ?></td>
          <td>Lend ID : <?php echo $results['lendid']; ?></td>
          <td><?php echo $results['lamount']; ?></td>
          <td><?php echo $results['recievedate']; ?></td>
         <td><?php echo $results['status']; ?></td>
          
          <td>


              
<form action="/bookkeeperv2/updatelendrecord2.php" method="post">
              <input type="submit" name="edit" value="UPDATE" />
              <input type="hidden" name="editlendid" value="<?php echo $results['lendid'] ?>" />
              <input type="hidden" name="editstatus" value="<?php echo $results['status'] ?>" />
              
             
              
              
            </form><br>

          	
          	<form action="/bookkeeperv2/deletelendrecord.php" method="post">
              <input type="submit" name="delete" value="DECLINE" />
              <input type="hidden" name="deleteId" value="<?php echo $results['lendid'] ?>"/>
            </form>
          </td>

        
        </tr><?php } ?>
      





        
        
        
<?php

require('readwithdrawtransac.php');

?>

        	<?php while($results = mysqli_fetch_array($sqlAccounts)) { ?>
          <td><?php echo $results['idnumber']; ?></td>
          <td>Witdraw ID : <?php echo $results['withdrawid']; ?></td>
          <td><?php echo $results['wamount']; ?></td>
          <td><?php echo $results['releasedate']; ?></td>
          <td><?php echo $results['status']; ?></td>
          <td>
          	

           <form action="/bookkeeperv2/updatewithdrawrecord2.php" method="post">
              <input type="submit" name="edit" value="UPDATE" />
              <input type="hidden" name="editwithdrawid" value="<?php echo $results['withdrawid'] ?>" />
              <input type="hidden" name="editstatus" value="<?php echo $results['status'] ?>" />
              
             
              
              
            </form><br>






          	<form action="/bookkeeperv2/deletewithdrawrecord.php" method="post">
              <input type="submit" name="delete" value="DECLINE" />
              <input type="hidden" name="deleteId" value="<?php echo $results['withdrawid'] ?>"/>
            </form>
          </td>


        
        </tr><?php } ?>
      </table>

    
  

         
         

		
  </div>



</body>
</html>


