<?php 
  require('./database.php');

 

  $queryAccounts = "SELECT * FROM lend_record";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);


?>