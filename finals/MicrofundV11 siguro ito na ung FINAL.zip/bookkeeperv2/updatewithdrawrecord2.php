<?php 
  require('./database.php');

  if (isset($_POST["edit"])) {
    $editwithdrawid = $_POST['editwithdrawid'];
    $editstatus= $_POST['editstatus'];    
    
    
    

  }

  if (isset($_POST['update'])) {

    
    $updatewithdrawid= $_POST['updatewithdrawid']; 
    $updatestatus = $_POST['updatestatus'];
    
    
    

    

    $queryUpdate = "UPDATE withdraw_record SET status = '$updatestatus' WHERE withdrawid = $updatewithdrawid";
    $sqlUpdate = mysqli_query($connection, $queryUpdate);

    echo '<script>alert("Successfully updated!")</script>';
    echo '<script>window.location.href = "/bookkeeperv2/pending.php"</script>';
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  

  <title>Update</title>
</head>


<style>
  
.<style>
  html, body {
    margin: 0;
    padding: 0;
  }
  .main {
    height: 100vh;

    /* Grid */
    display: grid;
    grid-template-rows: auto 1fr;
    justify-items: center;
    row-gap: 20px;
    
  }
  .main .update-main {
    grid-row: 1/2;
    display: grid;
    grid-auto-rows: auto;
    row-gap: 5px;
  }
  .main .update-main h3 {
    text-align: center;
  }

  header {
    background-color: #1e283a;
}

nav ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

nav li {
    float: right;
    width: 20%;
}

nav li a {
    display: block;
    color: white;
    text-align: center;
    padding: 20px 25px;
    text-decoration: none;
}

nav li a:hover {
    background-color: #111;
}

/*header end*/

h1 {
    font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
    font-size: 36px;
    font-style: normal;
    font-variant: normal;
    font-weight: 500;
    line-height: 24px;
}

h2 {
    font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
    font-size: 28px;
    font-style: normal;
    font-variant: normal;
    font-weight: 500;
    line-height: 20px;
}

p {
    font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
    font-size: 20px; font-style: normal;
    font-variant: normal;
    font-weight: 300;
    line-height: 28px;
}

ul {
    font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
    font-size: 20px; font-style: normal;
    font-variant: normal;
    font-weight: 300;
    line-height: 28px;
}

li {
    font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
    font-size: 20px; font-style: normal;
    font-variant: normal;
    font-weight: 300;
    line-height: 28px;
}

blockquote {
    font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
    font-size: 21px;
    font-style: normal;
    font-variant: normal;
    font-weight: 400;
    line-height: 30px;

}

pre {
    font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
    font-size: 13px;
    font-style: normal;
    font-variant: normal;
    font-weight: 400;
    line-height: 18.5667px;
}

.content1 img {
  display: block;
  margin-left: auto;
  margin-right: auto;
  height: 15vh;
  padding: 20px;
}
</style>
</style>
<body>
   

<div class="main">
    <form class="update-main" action="/bookkeeperv2/updatewithdrawrecord2.php" method="post">
      <h3>UPDATE USER:</h3>

          
           <input type="hidden" name="updatewithdrawid" placeholder="withdrawid" required/>
           <select name="updatestatus" value="<?php echo $editstatus?>">
  <option value="PENDING">PENDING</option>

  <option value="APPROVED">APPROVED</option>
  <option value="DENIED">DENIED</option>
  
  
</select><br>
          
      
      <input type="submit" name="update" value="UPDATE" />
      <input type="hidden" name="updatewithdrawid" value="<?php echo $editwithdrawid ?>" />
    </form>
</body>
</html>