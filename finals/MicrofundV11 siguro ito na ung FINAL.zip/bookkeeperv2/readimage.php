<?php 
  require('./database.php');

 

  $queryAccounts = "SELECT * FROM image";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);


?>