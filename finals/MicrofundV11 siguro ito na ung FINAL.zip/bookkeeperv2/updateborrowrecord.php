<?php 
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>
<?php 
  require('./database.php');

  if (isset($_POST["edit"])) {
    $editborrowID = $_POST['editborrowID'];
    $editamount = $_POST['editamount'];    
    $editpromisedate = $_POST['editpromisedate'];
    $editbdescription = $_POST['editbdescription'];
    
    

  }

  if (isset($_POST['update'])) {

    
    $updateborrowID = $_POST['updateborrowID']; 
    $updateamount = $_POST['updateamount'];
    $updatepromisedate= $_POST['updatepromisedate'];
    $updatebdescription= $_POST['updatebdescription'];
    
    

    

    $queryUpdate = "UPDATE borrow_record SET amount = '$updateamount', promisedate = '$updatepromisedate', bdescription = '$updatebdescription' WHERE borrowID = $updateborrowID";
    $sqlUpdate = mysqli_query($connection, $queryUpdate);

    echo '<script>alert("Successfully updated!")</script>';
    echo '<script>window.location.href = "/bookkeeperv2/process.php"</script>';
  }
?>

<!DOCTYPE html>

<head>

  <html lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<header>
  <style>
.divTableRow{
  margin: 10px;
  width: 100%;
}

table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
h2{
  font-family: arial, sans-serif;
  margin: 10px;
}

.divTableCell button a{
  color: white;
}


/*start*/

body {
  margin: 0;
}


h1 {
  font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
  
  
}


li, a, button {
  font-weight: 500;
  font-size: 18px;
  text-decoration: none;
}

a {
  color: #2196F3;
}

header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px ;
  background-color: #363633;
}


.active-header {
  background-color: #363633;
  color: #ffffff;
  padding: 30px 35px;
}

.logo {
  cursor: pointer;
  height: 30px;
  width: 90px;
  
}


.nav__links {
  list-style: none;
}

.nav__links li {
  display: inline-block;
  
}



.nav__links li a:hover {
  background-color: black;
  
}



button {
  color: #ffffff;
  padding: 9px 25px;
  background-color: #0099f7;
  border: none;
  border-radius: 50px;
  cursor: pointer;
  transition: all 0.3s ease 0s; 
}

button:hover {
  background-color: #c6f1f5;
  color: #000000;
}

.main {
  padding: 5%;
}

.main .contributortable {
  text-align: center;
  font-size: 20px;
  padding: 25px 50px; 
  border-style: solid;
  width: 100%;
  border-color: green ;
  font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
   
}

.main .contributortable tr th {
  padding: 10px;
}

.action {
  color: white;
}

#action {
  width: 10vh;
  background-color:#111;
  
}

#action:hover {
  
  background-color: green;
}

.actiond {
  color: white;
}

#actiond {
  width: 10vh;
  background-color:#111;
  
}

#actiond:hover {
  
  background-color: red;
}
.addbutton {
  
  float: right;
  margin-right: 80%;
  border-style: solid;
  border-color: black;
  font-family: Segoe UI, Frutiger, Frutiger Linotype, Dejavu Sans, Helvetica Neue, Arial, sans-serif;
  padding: 10px 50px;
  font-size: 20px;;
  
  
}

.addbutton:hover {
  background-color: green;
  color: white;
}

td{
  padding: 5px;
}

.addbutton {
  text-align: center;
}

.update-main {
  margin-right: 30%;
  margin-left: 30%;
  font-size: 20px;

}


input {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #d1cdcd;
  border-radius: 3px;
}

input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
input[type=submit]:hover {
 background: green;
 color: white;
}





</style>
  <a href="/bookkeeperv2/index.php"><img class="logo" src="image/silver-coin.jpg" alt="logo"></a>
  <nav>
    <ul class="nav__links"> 
      <li><a class="active-header" href="/bookkeeperv2/index.php">HOME</a></li>
      <li><a class="active-header" href="/bookkeeperv2/profile.php">PROFILE</a></li>
      <li><a class="active-header" href="/bookkeeperv2/process.php">PROCESS</a></li>
      <li><a class="active-header" href="/bookkeeperv2/Financial-Statement.php">FINANCIAL STATEMENT</a></li>
      <li><a class="active-header" href="/bookkeeperv2/pending.php">PENDING</a></li>
      <li><a class="active-header" href="/bookkeeperv2/ledger.php">LEDGER</a></li>
      
    </ul>
  </nav>
  <a class="cta" href="logout.php"><button>Logout</button></a>
</header>
</head>
<body>
   

<div class="main">
    <form class="update-main" action="/bookkeeperv2/updateborrowrecord.php" method="post">
      <h3>UPDATE BORROW:</h3>

          <b>Amount</b><input type="number" name="updateamount" placeholder="Amount" value="<?php echo $editamount?>" required/><br>
          <b>Promise Date</b><input type="date" name="updatepromisedate" placeholder="Promise Date" value="<?php echo $editpromisedate?>" required/><br>
          <b>Description</b><input type="text" name="updatebdescription" placeholder="Description" value="<?php echo $editbdescription?>" required/><br>
      
      <input type="submit" name="update" value="UPDATE" />
      <input type="hidden" name="updateborrowID" value="<?php echo $editborrowID ?>" />
    </form>
</body>
</html>