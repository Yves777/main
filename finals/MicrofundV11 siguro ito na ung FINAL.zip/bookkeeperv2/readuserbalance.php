
<?php 
  require('./database.php');

 


  $queryAccounts = "SELECT 
    ((SELECT coalesce(SUM(lamount),0) FROM lend_record where idnumber = '$str') + 
    (SELECT coalesce(SUM(pamount),0) FROM payment_record where idnumber = '$str')) -
    ((SELECT coalesce(SUM(amount),0) FROM borrow_record where idnumber = '$str') +
    (SELECT coalesce(SUM(wamount),0) FROM withdraw_record where idnumber = '$str')) as currentfunds";





  $sqlAccounts = mysqli_query($connection, $queryAccounts);
 
?>