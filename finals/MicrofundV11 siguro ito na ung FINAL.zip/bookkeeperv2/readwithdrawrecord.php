<?php 
  require('./database.php');
 

  $queryAccounts = "SELECT * FROM withdraw_record inner join user on withdraw_record.idnumber = user.idnumber order by withdrawid desc";
  $sqlAccounts = mysqli_query($connection, $queryAccounts);
?>