<?php

session_start();

if(isset($_SESSION['idnumber']))
{
	unset($_SESSION['idnumber']);

}

header("Location: /bookkeeperv2/index.php");
die;