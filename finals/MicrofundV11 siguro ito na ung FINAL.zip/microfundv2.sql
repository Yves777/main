-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 28, 2021 at 03:04 AM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `microfundv2`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrow_record`
--

DROP TABLE IF EXISTS `borrow_record`;
CREATE TABLE IF NOT EXISTS `borrow_record` (
  `borrowID` int NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(45) DEFAULT NULL,
  `comakerid` varchar(45) DEFAULT NULL,
  `amount` varchar(45) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `promisedate` varchar(45) DEFAULT NULL,
  `method` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `bdescription` varchar(900) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  PRIMARY KEY (`borrowID`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `comaker`
--

DROP TABLE IF EXISTS `comaker`;
CREATE TABLE IF NOT EXISTS `comaker` (
  `comaker_id` int NOT NULL AUTO_INCREMENT,
  `cm_fname` varchar(45) DEFAULT NULL,
  `cm_mname` varchar(45) DEFAULT NULL,
  `cm_lname` varchar(45) DEFAULT NULL,
  `houseno` varchar(45) DEFAULT NULL,
  `street` varchar(45) DEFAULT NULL,
  `barangay` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `province` varchar(45) DEFAULT NULL,
  `contactnumber` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`comaker_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
CREATE TABLE IF NOT EXISTS `image` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(200) NOT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `paymentid` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lend_record`
--

DROP TABLE IF EXISTS `lend_record`;
CREATE TABLE IF NOT EXISTS `lend_record` (
  `lendid` int NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(45) DEFAULT NULL,
  `lamount` varchar(45) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `recievedate` varchar(45) DEFAULT NULL,
  `method` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `ldescription` varchar(900) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  PRIMARY KEY (`lendid`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment_record`
--

DROP TABLE IF EXISTS `payment_record`;
CREATE TABLE IF NOT EXISTS `payment_record` (
  `paymentid` int NOT NULL AUTO_INCREMENT,
  `borrowid` int DEFAULT NULL,
  `idnumber` int DEFAULT NULL,
  `pdate` varchar(50) DEFAULT NULL,
  `pamount` int DEFAULT NULL,
  `method` varchar(50) DEFAULT NULL,
  `pstatus` varchar(50) DEFAULT NULL,
  `pdescription` varchar(900) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `idnumber` int NOT NULL,
  `firstname` varchar(45) DEFAULT NULL,
  `middlename` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `houseno` varchar(45) DEFAULT NULL,
  `street` varchar(45) DEFAULT NULL,
  `barangay` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `province` varchar(45) DEFAULT NULL,
  `contactnumber` varchar(15) DEFAULT NULL,
  `emailaddress` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `borrowbalance` int DEFAULT NULL,
  `contributionbalance` int DEFAULT NULL,
  `access_level` int NOT NULL,
  PRIMARY KEY (`idnumber`),
  UNIQUE KEY `idnumber_UNIQUE` (`idnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_record`
--

DROP TABLE IF EXISTS `withdraw_record`;
CREATE TABLE IF NOT EXISTS `withdraw_record` (
  `withdrawid` int NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(45) DEFAULT NULL,
  `wamount` varchar(45) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `releasedate` varchar(45) DEFAULT NULL,
  `method` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `wdescription` varchar(900) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  PRIMARY KEY (`withdrawid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
